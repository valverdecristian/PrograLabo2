﻿using Entidades;
using System;
using System.Collections.Generic;
using System.IO;

namespace Archivo
{
    internal class Texto
    {

    }
}
