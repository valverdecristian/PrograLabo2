﻿using System;

namespace Entidades
{
    internal class PatenteInvalidaException
    {

    }
}
